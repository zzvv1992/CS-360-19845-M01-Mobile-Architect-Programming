package com.example.zachariahvalentimodulethree;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect Java variables to the controls in activity_main.xml.
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createButton);

        // Open the SQLite database.
        databaseHelper = new DatabaseHelper(this);

        // Log in using an existing account.
        loginButton.setOnClickListener(v -> loginUser());

        // Create a new account.
        createAccountButton.setOnClickListener(v -> createAccount());
    }

    private void loginUser() {

        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Make sure both fields contain information.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Check the username and password against the database.
        if (databaseHelper.checkUser(username, password)) {

            Toast.makeText(
                    this,
                    "Login successful.",
                    Toast.LENGTH_SHORT
            ).show();

            // Open the inventory screen.
            Intent inventoryIntent =
                    new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(inventoryIntent);

// Ask the user about optional SMS notifications.
            Intent smsIntent =
                    new Intent(MainActivity.this, SmsActivity.class);
            startActivity(smsIntent);

        } else {

            Toast.makeText(
                    this,
                    "Incorrect username or password.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void createAccount() {

        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Do not allow blank usernames or passwords.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Save the new account to SQLite.
        boolean accountCreated =
                databaseHelper.createUser(username, password);

        if (accountCreated) {

            Toast.makeText(
                    this,
                    "Account created successfully. You can now log in.",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            Toast.makeText(
                    this,
                    "That username already exists.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}