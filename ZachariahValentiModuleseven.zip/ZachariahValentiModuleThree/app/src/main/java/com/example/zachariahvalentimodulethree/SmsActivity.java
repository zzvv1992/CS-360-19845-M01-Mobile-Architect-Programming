package com.example.zachariahvalentimodulethree;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// Handles the user's SMS permission choice.
public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private Button allowSmsButton;
    private Button denySmsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        allowSmsButton = findViewById(R.id.allowSmsButton);
        denySmsButton = findViewById(R.id.denySmsButton);

        // Ask Android for SMS permission.
        allowSmsButton.setOnClickListener(v -> requestSmsPermission());

        // Continue using the app without SMS notifications.
        denySmsButton.setOnClickListener(v -> {
            Toast.makeText(
                    this,
                    "SMS notifications will remain disabled.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
        });
    }

    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "SMS notifications are already enabled.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(
                        this,
                        "SMS notifications enabled.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "Permission denied. The app will continue without SMS notifications.",
                        Toast.LENGTH_LONG
                ).show();
            }

            finish();
        }
    }
}