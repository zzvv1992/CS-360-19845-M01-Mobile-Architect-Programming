package com.example.zachariahvalentimodulethree;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;

// Displays and manages inventory items stored in SQLite.
public class InventoryActivity extends AppCompatActivity {

    private EditText itemNameEditText;
    private EditText itemQuantityEditText;
    private Button addItemButton;
    private LinearLayout inventoryContainer;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemQuantityEditText = findViewById(R.id.itemQuantityEditText);
        addItemButton = findViewById(R.id.addItemButton);
        inventoryContainer = findViewById(R.id.inventoryContainer);

        addItemButton.setOnClickListener(v -> addItem());

        loadInventory();
    }

    // Adds a new item to the SQLite database.
    private void addItem() {

        String itemName = itemNameEditText.getText().toString().trim();
        String quantityText = itemQuantityEditText.getText().toString().trim();

        if (itemName.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter an item name and quantity.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    "Quantity must be a number.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        boolean added = databaseHelper.addItem(itemName, quantity);

        if (added) {
            Toast.makeText(
                    this,
                    "Item added.",
                    Toast.LENGTH_SHORT
            ).show();

            itemNameEditText.setText("");
            itemQuantityEditText.setText("");

            loadInventory();
        } else {
            Toast.makeText(
                    this,
                    "Unable to add item.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Reads all inventory items from the database and displays them.
    private void loadInventory() {

        inventoryContainer.removeAllViews();

        Cursor cursor = databaseHelper.getAllItems();

        if (cursor.getCount() == 0) {

            TextView emptyView = new TextView(this);
            emptyView.setText("No inventory items yet.");
            emptyView.setPadding(8, 16, 8, 16);

            inventoryContainer.addView(emptyView);

            cursor.close();
            return;
        }

        while (cursor.moveToNext()) {

            int id = cursor.getInt(0);
            String itemName = cursor.getString(1);
            int quantity = cursor.getInt(2);

            createInventoryRow(id, itemName, quantity);
        }

        cursor.close();
    }

    // Creates one visible inventory row with update and delete controls.
    private void createInventoryRow(int id, String itemName, int quantity) {

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(12, 16, 12, 16);

        TextView itemIdText = new TextView(this);
        itemIdText.setText("Item ID: " + id);

        EditText nameEditText = new EditText(this);
        nameEditText.setText(itemName);
        nameEditText.setHint("Item Name");

        EditText quantityEditText = new EditText(this);
        quantityEditText.setText(String.valueOf(quantity));
        quantityEditText.setHint("Quantity");
        quantityEditText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        Button updateButton = new Button(this);
        updateButton.setText("Update");

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");

        updateButton.setOnClickListener(v ->
                updateItem(id, nameEditText, quantityEditText));

        deleteButton.setOnClickListener(v ->
                deleteItem(id));

        row.addView(itemIdText);
        row.addView(nameEditText);
        row.addView(quantityEditText);
        row.addView(updateButton);
        row.addView(deleteButton);

        inventoryContainer.addView(row);
    }

    // Updates an existing inventory item.
    private void updateItem(
            int id,
            EditText nameEditText,
            EditText quantityEditText) {

        String itemName =
                nameEditText.getText().toString().trim();

        String quantityText =
                quantityEditText.getText().toString().trim();

        if (itemName.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(
                    this,
                    "Item name and quantity cannot be blank.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    "Quantity must be a number.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        boolean updated =
                databaseHelper.updateItem(id, itemName, quantity);

        if (updated) {

            Toast.makeText(
                    this,
                    "Item updated.",
                    Toast.LENGTH_SHORT
            ).show();

            // Send an SMS alert if the inventory reaches zero.
            if (quantity <= 0) {
                sendLowInventoryAlert(itemName);
            }

            loadInventory();
        }
    }

    // Deletes an inventory item from SQLite.
    private void deleteItem(int id) {

        boolean deleted =
                databaseHelper.deleteItem(id);

        if (deleted) {
            Toast.makeText(
                    this,
                    "Item deleted.",
                    Toast.LENGTH_SHORT
            ).show();

            loadInventory();
        }
    }
    // Sends a low-inventory SMS alert if permission was granted.
    private void sendLowInventoryAlert(String itemName) {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            try {

                SmsManager smsManager = SmsManager.getDefault();

                // Emulator/test phone number for demonstration purposes.
                smsManager.sendTextMessage(
                        "5551234567",
                        null,
                        "Inventory Alert: " + itemName + " is out of stock.",
                        null,
                        null
                );

                Toast.makeText(
                        this,
                        "Low inventory SMS alert sent.",
                        Toast.LENGTH_SHORT
                ).show();

            } catch (Exception e) {

                Toast.makeText(
                        this,
                        "SMS alert could not be sent.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } else {

            // Inventory still works normally if SMS permission was denied.
            Toast.makeText(
                    this,
                    "Item is out of stock. SMS notifications are disabled.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}
